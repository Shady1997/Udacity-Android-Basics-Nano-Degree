package com.shady191997.tourguid;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.shady191997.tourguid.fragments.PageFragment1;
import com.shady191997.tourguid.fragments.PageFragment2;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {

    ListView list1;
    AppData data;
    MyListAdapter adapter;
    private ViewPager pager;
    private PagerAdapter pagerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //using Fragments

        data = new AppData();
        List<Fragment> list = new ArrayList<>();
        String name = getIntent().getStringExtra("name");

        if (name.equals("restaurant")) {
            PageFragment1.setImg(data.getRestaurants_imgs()[0]);
            PageFragment1.setTxt(data.getRestaurants_names()[0]);
            PageFragment1.setGeo(data.getRestaurants_geo()[0]);
            PageFragment2.setImg(data.getRestaurants_imgs()[1]);
            PageFragment2.setTxt(data.getRestaurants_names()[1]);
            PageFragment2.setGeo(data.getRestaurants_geo()[1]);
            list.add(new PageFragment1());
            list.add(new PageFragment2());
            pager = findViewById(R.id.pager);
            pagerAdapter = new SlidePageAdapter(getSupportFragmentManager(), list);
            pager.setAdapter(pagerAdapter);
        } else if (name.equals("mosque")) {
            PageFragment1.setImg(data.getMosques_imgs()[0]);
            PageFragment1.setTxt(data.getMosques_names()[0]);
            PageFragment1.setGeo(data.getMosques_geo()[0]);
            PageFragment2.setImg(data.getMosques_imgs()[1]);
            PageFragment2.setTxt(data.getMosques_names()[1]);
            PageFragment2.setGeo(data.getMosques_geo()[1]);
            list.add(new PageFragment1());
            list.add(new PageFragment2());
            pager = findViewById(R.id.pager);
            pagerAdapter = new SlidePageAdapter(getSupportFragmentManager(), list);
            pager.setAdapter(pagerAdapter);
        } else if (name.equals("museum")) {
            PageFragment1.setImg(data.getMuseums_imgs()[0]);
            PageFragment1.setTxt(data.getMuseums_names()[0]);
            PageFragment1.setGeo(data.getMuseums_geo()[0]);
            list.add(new PageFragment1());
            pager = findViewById(R.id.pager);
            pagerAdapter = new SlidePageAdapter(getSupportFragmentManager(), list);
            pager.setAdapter(pagerAdapter);
        } else if (name.equals("market")) {
            PageFragment2.setImg(data.getMarkets_imgs()[0]);
            PageFragment2.setTxt(data.getMarkets_names()[0]);
            PageFragment2.setGeo(data.getMarkets_geo()[0]);
            list.add(new PageFragment2());
            pager = findViewById(R.id.pager);
            pagerAdapter = new SlidePageAdapter(getSupportFragmentManager(), list);
            pager.setAdapter(pagerAdapter);
        }


        //using listView

//        String name = getIntent().getStringExtra("name");
//
//        if (name.equals("restaurant")) {
//            data = new AppData();
//            adapter = new MyListAdapter(Main2Activity.this, data.getRestaurants_names(), data.getRestaurants_imgs(),1);
//            list1 = (ListView) findViewById(R.id.ls1);
//            list1.setAdapter(adapter);
//            list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    if (position == 0) {
//
//
//                    }
//
//                    else if(position==1)
//                    {
//
//
//                    }
//                }
//            });
//
//        } else if (name.equals("mosque")) {
//            data = new AppData();
//            adapter = new MyListAdapter(Main2Activity.this, data.getMosques_names(), data.getMosques_imgs(),3);
//            list1 = (ListView) findViewById(R.id.ls1);
//            list1.setAdapter(adapter);
//            list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    if (position == 0) {
//
//
//                    }
//                    else if(position==1)
//                    {
//
//
//                    }
//                }
//            });
//        }
//
//        else if (name.equals("museum")) {
//            data = new AppData();
//            adapter = new MyListAdapter(Main2Activity.this, data.getMuseums_names(), data.getMuseums_imgs(),2);
//            list1 = (ListView) findViewById(R.id.ls1);
//            list1.setAdapter(adapter);
//            list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    if (position == 0) {
//
//
//                    }
//                }
//            });
//        }
//
//        else if (name.equals("market")) {
//            data = new AppData();
//            adapter = new MyListAdapter(Main2Activity.this, data.getMarkets_names(), data.getMarkets_imgs(),4);
//            list1 = (ListView) findViewById(R.id.ls1);
//            list1.setAdapter(adapter);
//            list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    if (position == 0) {
//
//
//                    }
//                }
//            });
//        }


        getSupportActionBar().setTitle("Choose Your location");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {

            onBackPressed();
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

}
