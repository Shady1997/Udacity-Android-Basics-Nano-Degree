package com.shady191997.tourguid.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.shady191997.tourguid.R;

public class PageFragment2 extends Fragment {
    ImageView imageView2;
    TextView textView2;
    static Integer img1;
    static String txt1;
    Button btn2;
    static String geo1;

    public static void setGeo(String geo) {
        PageFragment2.geo1 = geo;
    }

    public static void setImg(Integer img) {
        PageFragment2.img1 = img;
    }


    public static void setTxt(String txt) {
        PageFragment2.txt1 = txt;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.page2, container, false);
        imageView2 = (ImageView) rootview.findViewById(R.id.img2);
        textView2 = (TextView) rootview.findViewById(R.id.txt2);
        btn2 = (Button) rootview.findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri1 = Uri.parse(geo1);
                Intent mapIntent1 = new Intent(Intent.ACTION_VIEW, gmmIntentUri1);
                mapIntent1.setPackage("com.google.android.apps.maps");
                //if (mapIntent.resolveActivity() != null)
                {
                    startActivity(mapIntent1);
                }
            }
        });

        chgimg();
        chgtxt();
        return rootview;
    }

    public void chgimg() {

        imageView2.setImageResource(img1);
    }

    public void chgtxt() {

        textView2.setText(txt1);
    }
}
