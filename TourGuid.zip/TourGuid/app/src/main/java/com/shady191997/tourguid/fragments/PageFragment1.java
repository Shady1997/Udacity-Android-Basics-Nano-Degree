package com.shady191997.tourguid.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.shady191997.tourguid.Main2Activity;
import com.shady191997.tourguid.R;

public class PageFragment1 extends Fragment {
    ImageView imageView1;
    TextView textView1;
    static Integer img1;
    static String txt1;
    Button btn1;
    static String geo;

    public static void setGeo(String geo) {
        PageFragment1.geo = geo;
    }

    public static void setImg(Integer img) {
        PageFragment1.img1 = img;
    }


    public static void setTxt(String txt) {
        PageFragment1.txt1 = txt;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.page1, container, false);
        imageView1 = (ImageView) rootview.findViewById(R.id.img1);
        textView1 = (TextView) rootview.findViewById(R.id.txt1);
        btn1 = (Button) rootview.findViewById(R.id.btn1);
        chgimg();
        chgtxt();
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri = Uri.parse(geo);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                //if (mapIntent.resolveActivity() != null)
                {
                    startActivity(mapIntent);
                }
            }
        });

        return rootview;
    }

    public void chgimg() {

        imageView1.setImageResource(img1);
    }

    public void chgtxt() {

        textView1.setText(txt1);
    }


}
