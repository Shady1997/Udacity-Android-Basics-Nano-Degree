package com.shady191997.scorekeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView player1;
    TextView player2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        player1 = (TextView) findViewById(R.id.textView3);
        player2 = (TextView) findViewById(R.id.textView4);
    }

    public void ptwo1(View view) {

        player1.setText(Integer.toString(Integer.parseInt(player1.getText().toString()) + 2));

        player2.setText(Integer.toString(Integer.parseInt(player2.getText().toString()) - 2));

    }

    public void pfour1(View view) {
        player1.setText(Integer.toString(Integer.parseInt(player1.getText().toString()) + 4));

        player2.setText(Integer.toString(Integer.parseInt(player2.getText().toString()) - 4));

    }

    public void mtwo1(View view) {

        player1.setText(Integer.toString(Integer.parseInt(player1.getText().toString()) - 2));
        player2.setText(Integer.toString(Integer.parseInt(player2.getText().toString()) + 2));
    }

    public void ptwo2(View view) {
        player2.setText(Integer.toString(Integer.parseInt(player2.getText().toString()) + 2));

        player1.setText(Integer.toString(Integer.parseInt(player1.getText().toString()) - 2));
    }

    public void pfour2(View view) {
        player2.setText(Integer.toString(Integer.parseInt(player2.getText().toString()) + 4));

        player1.setText(Integer.toString(Integer.parseInt(player1.getText().toString()) - 4));

    }

    public void mtwo2(View view) {

        player2.setText(Integer.toString(Integer.parseInt(player2.getText().toString()) - 2));
        player1.setText(Integer.toString(Integer.parseInt(player1.getText().toString()) + 2));
    }

    public void reset(View view) {
        player1.setText("0");
        player2.setText("0");
    }
}
