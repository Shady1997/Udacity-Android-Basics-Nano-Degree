package com.shady191997.musicalplayer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class Main2Activity extends AppCompatActivity {
    ListView list1;
    AppData data;
    MyListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String name = getIntent().getStringExtra("name");


        if (name.equals("abdelhalim")) {
            data = new AppData();
            adapter = new MyListAdapter(Main2Activity.this, data.getAbd_SongeName(), data.getAbd_SongeImg());
            list1 = (ListView) findViewById(R.id.ls1);
            list1.setAdapter(adapter);
            list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0) {

                        Intent intent1 = new Intent(Main2Activity.this, Main3Activity.class);
                        intent1.putExtra("song", "kareat El Fengan");
                        startActivity(intent1);
                    }
                }
            });

        } else if (name.equals("omkolthom")) {
            data = new AppData();
            adapter = new MyListAdapter(Main2Activity.this, data.getOm_SongName(), data.getOm_SongeImg());
            list1 = (ListView) findViewById(R.id.ls1);
            list1.setAdapter(adapter);
            list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0) {

                        Intent intent1 = new Intent(Main2Activity.this, Main3Activity.class);
                        intent1.putExtra("song", "Enta Omery");
                        startActivity(intent1);
                    }
                }
            });
        }


        getSupportActionBar().setTitle("Choose a Song from the list to play");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {

            onBackPressed();
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
