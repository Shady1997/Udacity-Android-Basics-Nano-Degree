package com.shady191997.musicalplayer;

public class AppData {
    // data to use in app include artist names and songs names
    private final String[] SongerName = {"Abd el halim hafez", "Om kolthom"};
    private final Integer[] SongerImg = {R.drawable.img1, R.drawable.img3};

    private final String[] abd_SongeName = {"Kareat El fengan is the most popular songs for this artist"};
    private final Integer[] abd_SongeImg = {R.drawable.img11};

    private final String[] om_SongName = {"Enta Omery is one of the most popular songs in africa and middle east"};
    private final Integer[] om_SongeImg = {R.drawable.img33};

    public Integer[] getAbd_SongeImg() {
        return abd_SongeImg;
    }

    public Integer[] getOm_SongeImg() {
        return om_SongeImg;
    }

    public String[] getOm_SongName() {
        return om_SongName;
    }

    public String[] getAbd_SongeName() {
        return abd_SongeName;
    }

    public String[] getSongerName() {
        return SongerName;
    }

    public Integer[] getSongerImg() {
        return SongerImg;
    }
}
