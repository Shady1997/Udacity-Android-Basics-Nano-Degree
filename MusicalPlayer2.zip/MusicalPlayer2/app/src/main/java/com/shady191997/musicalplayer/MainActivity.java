package com.shady191997.musicalplayer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AppData data = new AppData();
        MyListAdapter adapter = new MyListAdapter(MainActivity.this, data.getSongerName(), data.getSongerImg());
        list = (ListView) findViewById(R.id.ls);
        list.setAdapter(adapter);
        getSupportActionBar().setTitle("Choose an Artist from the list");
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position == 0) {
                    Intent intenta = new Intent(MainActivity.this, Main2Activity.class);
                    intenta.putExtra("name", "abdelhalim");
                    startActivity(intenta);
                } else if (position == 1) {
                    Intent intentb = new Intent(MainActivity.this, Main2Activity.class);
                    intentb.putExtra("name", "omkolthom");
                    startActivity(intentb);
                }


            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {

            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }
}
