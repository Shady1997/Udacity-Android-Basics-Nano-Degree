package com.shady191997.musicalplayer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class PlayerActivity extends AppCompatActivity {

    Button btnNext, btnPrevious, btnPause;
    TextView songTextLabel;
    SeekBar songSeekBar;

    static MediaPlayer myplayer;
    int position;
    String sName;

    ArrayList<File> mysong;
    Thread updateSeekBar;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        btnNext = (Button) findViewById(R.id.next);
        btnPrevious = (Button) findViewById(R.id.previous);
        btnPause = (Button) findViewById(R.id.pause);

        songTextLabel = (TextView) findViewById(R.id.songlabel);

        songSeekBar = (SeekBar) findViewById(R.id.seekBar);

        getSupportActionBar().setTitle("Now Playing");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        updateSeekBar = new Thread() {
            @Override
            public void run() {
                int totalDuration = myplayer.getDuration();
                int currentPositio = 0;

                while (currentPositio < totalDuration) {

                    try {
                        sleep(500);
                        currentPositio = myplayer.getCurrentPosition();
                        songSeekBar.setProgress(currentPositio);

                    } catch (InterruptedException e) {

                        e.printStackTrace();
                    }
                }

            }
        };


        if (myplayer != null) {
            myplayer.stop();
            myplayer.release();

        }

        Intent i = getIntent();
        Bundle bundle = i.getExtras();
        if (i.getIntExtra("code", 1) == 0) {
            String songName = "sample";

            songTextLabel.setText(songName);
            songTextLabel.setSelected(true);


            myplayer = MediaPlayer.create(getApplicationContext(), R.raw.sample);
            myplayer.start();
            songSeekBar.setMax(myplayer.getDuration());


            updateSeekBar.start();
            songSeekBar.getProgressDrawable().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.MULTIPLY);
            songSeekBar.getThumb().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.SRC_IN);
        } else {
            mysong = (ArrayList) bundle.getParcelableArrayList("songs");


            sName = mysong.get(position).getName().toString();

            String songName = i.getStringExtra("songName");

            songTextLabel.setText(songName);
            songTextLabel.setSelected(true);

            position = bundle.getInt("pos", 0);
            Uri u = Uri.parse(mysong.get(position).toString());

            myplayer = MediaPlayer.create(getApplicationContext(), u);
            myplayer.start();
            songSeekBar.setMax(myplayer.getDuration());


            updateSeekBar.start();
            songSeekBar.getProgressDrawable().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.MULTIPLY);
            songSeekBar.getThumb().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.SRC_IN);
        }
        songSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                myplayer.seekTo(seekBar.getProgress());
            }
        });


        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                songSeekBar.setMax(myplayer.getDuration());

                if (myplayer.isPlaying()) {

                    btnPause.setBackgroundResource(R.drawable.icon_play);
                    myplayer.pause();
                } else {

                    btnPause.setBackgroundResource(R.drawable.icon_pause);
                    myplayer.start();
                }
            }
        });


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myplayer.stop();
                myplayer.release();
                position = ((position + 1) % mysong.size());

                Uri u = Uri.parse(mysong.get(position).toString());
                myplayer = MediaPlayer.create(getApplicationContext(), u);
                sName = mysong.get(position).getName().toString();
                songTextLabel.setText(sName);
                myplayer.start();
            }
        });


        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myplayer.stop();
                myplayer.release();
                position = ((position - 1) < 0) ? (mysong.size() - 1) : (position - 1);
                Uri u = Uri.parse(mysong.get(position).toString());
                myplayer = MediaPlayer.create(getApplicationContext(), u);
                sName = mysong.get(position).getName().toString();
                songTextLabel.setText(sName);
                myplayer.start();

            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {

            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }
}
