package android.example.musicalstructureapp;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class PopActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_list);

        ArrayList<Info> infos = new ArrayList<Info>();

        infos.add(new Info("Justin Bieber", "I Don't Care"));
        infos.add(new Info("Jonas Brothers", "Sucker"));
        infos.add(new Info("Shawn Mendes", "Senorita"));
        infos.add(new Info("Billie Eilish", "bad guy"));
        infos.add(new Info("Bradley Cooper", "Shallow"));
        infos.add(new Info("Sam Smith", "Dancing with a stranger"));
        infos.add(new Info("Shawn Mendes", "If i can't have you"));
        infos.add(new Info("Ed Sheeren", "Shape of you"));
        infos.add(new Info("Shakira", "Hips don't lie"));
        infos.add(new Info("Rihana", "Umbrella"));

        InfoAdapter adapter = new InfoAdapter(this,infos);

        ListView listView = (ListView)findViewById(R.id.list);

        listView.setAdapter(adapter);

    }
}
