package android.example.musicalstructureapp;

public class Info {
    private String mNameOfComposer;
    private String mInfo;

    public Info(String nameOfComposer, String info) {
        mNameOfComposer = nameOfComposer;
        mInfo = info;
    }

    public String getNameOfComposer() {
        return mNameOfComposer;
    }

    public String getInfo() {
        return mInfo;
    }
}
