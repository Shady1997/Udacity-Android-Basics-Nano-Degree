package android.example.musicalstructureapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ArabicActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_list);

        ArrayList<Info> infos = new ArrayList<Info>();

        infos.add(new Info("Amr Diab", "Wayah"));
        infos.add(new Info("ABU", "3 Daqat"));
        infos.add(new Info("Nancy Ajram", "Ah w Noss"));
        infos.add(new Info("Amr Diab", "Tamally Ma'ak"));
        infos.add(new Info("Mohamed Mounir", "Maddad"));
        infos.add(new Info("Sami Yusuf", "Muaalem"));
        infos.add(new Info("Saad Lamjared", "Maallem"));
        infos.add(new Info("Tamer Hosney", "Nour Einy"));
        infos.add(new Info("Mouhamed Mounir", "Shamandora"));
        infos.add(new Info("Mouhamed Mounir", "Yunis"));

        InfoAdapter adapter = new InfoAdapter(this, infos);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);

    }

}

