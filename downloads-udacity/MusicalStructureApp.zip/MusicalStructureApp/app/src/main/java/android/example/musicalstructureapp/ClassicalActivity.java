package android.example.musicalstructureapp;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ClassicalActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_list);

        ArrayList<Info> infos = new ArrayList<Info>();

        infos.add(new Info("Beethoven", "Symphony No. 9"));
        infos.add(new Info("Beethoven", "Symphony No. 3"));
        infos.add(new Info("Beethoven", "Sonata No. 8  \"Pathétique\""));
        infos.add(new Info("Mozart", "Oboe Concerto in C major"));
        infos.add(new Info("Mozart", "Sonata for Two Pianos in D"));
        infos.add(new Info("Mozart", "Piano Sonata No 16 C major "));
        infos.add(new Info("Haydn", "Piano Concerto No. 11 in D major"));
        infos.add(new Info("Haydn", "Symphony no. 94 \"Surprise\" "));
        infos.add(new Info("Haydn", "Symphony No. 45 \"Farewell\""));
        infos.add(new Info("Boccherini", "Minuet in E Major"));

        InfoAdapter adapter = new InfoAdapter(this, infos);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);

    }

}
