package android.example.tourguideapp;

public class Word {
    private int mNameId;
    private int mImageResourceId;

    public Word(int nameId, int imageResourceId) {
    mNameId = nameId;
    mImageResourceId = imageResourceId;
    }
    public int getNameId(){
        return mNameId;
    }
    public int getImageResourceId(){
        return mImageResourceId;
    }
}
