package android.example.tourguideapp;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class CaffesFragment extends Fragment {


    public CaffesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word(R.string.caffee_1, R.drawable.caffee1));
        words.add(new Word(R.string.caffee_2, R.drawable.caffee2));
        words.add(new Word(R.string.caffee_3, R.drawable.caffee3));
        words.add(new Word(R.string.caffee_4, R.drawable.caffee4));
        words.add(new Word(R.string.caffee_5, R.drawable.caffee5));
        words.add(new Word(R.string.caffee_6, R.drawable.caffee6));

        WordAdapter adapter = new WordAdapter(getActivity(), words);

        ListView listView = (ListView) rootView.findViewById(R.id.list);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Word word = words.get(i);
            }
        });
        return rootView;
    }
}
