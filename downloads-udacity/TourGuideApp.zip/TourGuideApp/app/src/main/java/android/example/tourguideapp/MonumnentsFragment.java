package android.example.tourguideapp;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class MonumnentsFragment extends Fragment {


    public MonumnentsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word(R.string.monuments_1, R.drawable.monuments1));
        words.add(new Word(R.string.monuments_2, R.drawable.monuments2));
        words.add(new Word(R.string.monuments_3, R.drawable.monuments3));
        words.add(new Word(R.string.monuments_4, R.drawable.monuments4));
        words.add(new Word(R.string.monuments_5, R.drawable.monuments5));

        WordAdapter adapter = new WordAdapter(getActivity(), words);

        ListView listView = (ListView) rootView.findViewById(R.id.list);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Word word = words.get(i);
            }
        });
        return rootView;
    }

}
