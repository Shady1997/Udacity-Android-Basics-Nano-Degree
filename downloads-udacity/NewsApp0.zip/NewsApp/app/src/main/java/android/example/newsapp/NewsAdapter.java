package android.example.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class NewsAdapter extends ArrayAdapter<News> {
    static class ViewHolder {

        private TextView sectionTextView;
        private TextView authorTextView;
        private TextView titleTextView;
        private TextView dateTextView;
        private TextView timeTextView;
    }

    public NewsAdapter(Context context, ArrayList<News> news) {
        super(context, 0, news);

    }

    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.news_list_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.sectionTextView = convertView.findViewById(R.id.section);
            viewHolder.authorTextView = convertView.findViewById(R.id.author);
            viewHolder.titleTextView = convertView.findViewById(R.id.title);
            viewHolder.dateTextView = convertView.findViewById(R.id.date);
            viewHolder.timeTextView = convertView.findViewById(R.id.time);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        News currentNews = getItem(position);

        SimpleDateFormat simpleDateFormat =
                new SimpleDateFormat("yyyy-MM-dd'T'kk:mm:ss'Z'", Locale.UK);
        Date dateObject = null;
        try {
            assert currentNews != null;
            dateObject = simpleDateFormat.parse(currentNews.getPublicationDate());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String formattedDate = formatDate(dateObject);
        String formattedTime = formatTime(dateObject);

        viewHolder.sectionTextView.setText(currentNews.getSectionName());
        viewHolder.authorTextView.setText(currentNews.getAuthor());
        viewHolder.titleTextView.setText(currentNews.getTitle());
        viewHolder.dateTextView.setText(formattedDate);
        viewHolder.timeTextView.setText(formattedTime);

        return convertView;
    }

    private String formatDate(Date dateObject) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("LLL dd, yyyy");
        return dateFormat.format(dateObject);
    }

    private String formatTime(Date dateObject) {
        SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a");
        return timeFormat.format(dateObject);
    }
}
