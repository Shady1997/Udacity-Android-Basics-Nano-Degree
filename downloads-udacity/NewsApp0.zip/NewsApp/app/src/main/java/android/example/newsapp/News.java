package android.example.newsapp;

public class News {

    private String mSectionName;
    private String mTitle;
    private String mAuthor;
    private String mPublicationDate;
    private String mUrl;

    public News(String sectionName, String author , String title , String date , String url)
    {
        mSectionName = sectionName;
        mAuthor = author;
        mTitle = title;
        mPublicationDate = date;
        mUrl = url;
    }
    public String getSectionName() {
        return mSectionName;
    }


    public String getAuthor() {
        return mAuthor;
    }


    public String getTitle() {
        return mTitle;
    }


    public String getPublicationDate() {
        return mPublicationDate;
    }


    public String getUrl() {
        return mUrl;
    }


}
