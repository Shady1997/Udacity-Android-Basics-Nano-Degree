package com.shady191997.personalquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Question one...

    RadioGroup questuin1;
    RadioButton question11;
    //Question two..

    RadioGroup questuin2;
    RadioButton question22;
    // Question Three..

    RadioGroup questuin3;
    RadioButton question33;
    //Question Four...

    RadioGroup questuin4;
    RadioButton question44;
    // Question Five...

    CheckBox question51;
    CheckBox question52;
    CheckBox question53;
    //Question six.....

    EditText question6;
    //show result...

    TextView showResult;
    //get result...

    Button getResult;
    //get selected radio button id...

    int radioidQ1;
    int radioidQ2;
    int radioidQ3;
    int radioidQ4;
    //calculate result....

    int result = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // objects declaration....

        questuin1 = (RadioGroup) findViewById(R.id.q1);
        questuin2 = (RadioGroup) findViewById(R.id.q2);
        questuin3 = (RadioGroup) findViewById(R.id.q3);
        questuin4 = (RadioGroup) findViewById(R.id.q4);
        //Question five....

        question51 = (CheckBox) findViewById(R.id.q51);
        question52 = (CheckBox) findViewById(R.id.q52);
        question53 = (CheckBox) findViewById(R.id.q53);
        // Question six....

        question6 = (EditText) findViewById(R.id.q6);
        //get and show result......

        showResult = (TextView) findViewById(R.id.result);
        getResult = (Button) findViewById(R.id.getresult);
        // get result button handler ...

        try {
            getResult.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    radioidQ1 = questuin1.getCheckedRadioButtonId();
                    question11 = (RadioButton) findViewById(radioidQ1);
                    if (radioidQ1 == 1) {
                        result += 1;
                        question11.setTextColor(getResources().getColor(R.color.selectedItem));
                    }

                    radioidQ2 = questuin2.getCheckedRadioButtonId();
                    question22 = (RadioButton) findViewById(radioidQ2);
                    if (radioidQ2 == 4) {
                        result += 1;
                        question22.setTextColor(getResources().getColor(R.color.selectedItem));
                    }

                    radioidQ3 = questuin3.getCheckedRadioButtonId();
                    question33 = (RadioButton) findViewById(radioidQ3);
                    if (radioidQ3 == 9) {
                        result += 1;
                        question33.setTextColor(getResources().getColor(R.color.selectedItem));
                    }

                    radioidQ4 = questuin4.getCheckedRadioButtonId();
                    question44 = (RadioButton) findViewById(radioidQ4);
                    if (radioidQ4 == 11) {
                        result += 1;
                        question44.setTextColor(getResources().getColor(R.color.selectedItem));
                    }

                    if (question52.isChecked() && question53.isChecked() && !question51.isChecked()) {
                        question52.setTextColor(getResources().getColor(R.color.selectedItem));
                        question53.setTextColor(getResources().getColor(R.color.selectedItem));
                        result += 1;
                    }
                    if (question6.getText().toString().contains("sheta el arab")) {
                        result += 1;
                    }

                    if (result > 4) {
                        showResult.setText("You pass the exam and your score is " + Integer.toString(result));
                        Toast.makeText(MainActivity.this, "your score is " + Integer.toString(result), Toast.LENGTH_LONG).show();
                    } else {
                        showResult.setText("You don't pass the exam and your score is " + Integer.toString(result));
                        Toast.makeText(MainActivity.this, "your score is " + Integer.toString(result), Toast.LENGTH_LONG).show();
                    }
                    result = 0;
                }
            });
        }catch (Exception e)
        {
            showResult.setText("You don't pass the exam and your score is " + Integer.toString(result));
            Toast.makeText(MainActivity.this, "your score is " + Integer.toString(result), Toast.LENGTH_LONG).show();
        }

    }

}
